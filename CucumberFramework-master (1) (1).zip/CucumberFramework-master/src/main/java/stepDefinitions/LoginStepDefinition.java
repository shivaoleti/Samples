package stepDefinitions;

import java.io.IOException;

import org.testng.annotations.Test;

import reusableActions.e2e_Scenario;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import extentReports.BaseTest;

public class LoginStepDefinition extends BaseTest {

	@Test
	@Given("^Navigate to GetSwift \"(.*)\"and user enters \"(.*)\" and \"(.*)\"$")
	public void getSwiftLogin(String Url, String username, String password) {
		e2e_Scenario obj1 = new e2e_Scenario();
		obj1.loginToGetSwift(Url, username, password);
	}

	@And("Verify home pages")
	public void getSwiftHomePage() {
		e2e_Scenario obj2 = new e2e_Scenario();
		obj2.verifyHomePage();

	}

	@Then("^Create new driver with required details$")
	public void getSwiftAddDrivers() {
		e2e_Scenario obj2 = new e2e_Scenario();
		obj2.addDrivers();

	}
}
