package reusableActions;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class e2e_Scenario extends objectRepositary{
	

	 public static WebDriver driver = null;
	 
	 commanFunctions cm = new commanFunctions();
	 
	 	String temp = cm.randomStringGenerator(3);
	 	String Phone = cm.numGeneration();

	    public String firstname = "Automation"+temp;
	    public String driverusername = "QAAUtomation"+temp;
	    public String driverEmailName = "cigautomation"+temp;
	    public String email = driverEmailName+"@gmail.com";
	    public String tempName = "Template"+temp;

	public void loginToGetSwift(String url, String username, String password) {
		System.setProperty("webdriver.chrome.driver","C://Automation_POC//CucumberTestNG//Drivers//chromedriver.exe");
		driver = new ChromeDriver();
		//driver = new HtmlUnitDriver();
		System.exit(0);
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		driver.get(url);
		driver.findElement(loginemail).sendKeys(username);
		driver.findElement(loginPassword).sendKeys(password);
		driver.findElement(loginButton).click();
	}
	
	public void verifyHomePage() {
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		driver.findElement(homeDashboard).isDisplayed();
		
		
	}
	public void addDrivers() {
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;
		driver.findElement(homeNavBurger).click();
		driver.findElement(drivers).click();
		driver.findElement(driverAddDrivers).click();
		driver.findElement(driverFirstName).sendKeys(firstname);
		driver.findElement(driverLastName).sendKeys(firstname);
		driver.findElement(driverEmail).sendKeys(email);
		driver.findElement(driverUsername).sendKeys(driverusername);
		driver.findElement(driverPhone).sendKeys(Phone);
		driver.findElement(driverPassword).sendKeys("getswift");
		driver.findElement(driverConfirmaPassword).sendKeys("getswift");
		driver.findElement(driverSubmit).click();
		
	}
	
}
