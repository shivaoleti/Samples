package reusableActions;

import org.openqa.selenium.By;

public class objectRepositary {
	
	//Login Page
	public static By loginemail = By.xpath("//*[@id='Email']");
	public static By loginPassword = By.xpath("//*[@id='Password']");
	public static By loginButton = By.xpath("//*[@id='form-account-login']/button");
	
	//Home Page
	public static By homeDashboard = By.xpath("//h1[text()='Dashboard']");
	public static By homeNavBurger = By.id("nav-burger");
	
	
	//Drivers Page
	public static By drivers = By.xpath("//*[text()='Drivers']");
	public static By driverAddDrivers = By.xpath("//button[text()='Add Drivers']");
	public static By driverFirstName = By.id("FirstName");
	public static By driverLastName = By.id("LastName");
	public static By driverEmail = By.id("Email");
	public static By driverUsername= By.id("Username");
	public static By driverPhone = By.id("Phone");
	public static By driverPassword = By.id("Password");
	public static By driverConfirmaPassword = By.id("ConfirmPassword");
	public static By driverSubmit = By.xpath("//*[text()='Submit']");
	
}
